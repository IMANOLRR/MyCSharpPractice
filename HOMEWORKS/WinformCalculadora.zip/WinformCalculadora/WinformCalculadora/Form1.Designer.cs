﻿namespace WinformCalculadora
{
    partial class Calculadora
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private Button GetButtonDelete()
        {
            return buttonDelete;
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listBox1 = new ListBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            buttonPlus = new Button();
            buttonLess = new Button();
            buttonMultiply = new Button();
            button0 = new Button();
            buttonLimpiar = new Button();
            buttonDivide = new Button();
            buttonCalcular = new Button();
            textBox1 = new TextBox();
            label1 = new Label();
            buttonEliminar = new Button();
            SuspendLayout();
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.Location = new Point(503, 60);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(207, 464);
            listBox1.TabIndex = 0;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // button1
            // 
            button1.Location = new Point(5, 95);
            button1.Name = "button1";
            button1.Size = new Size(122, 88);
            button1.TabIndex = 1;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button_Click;
            // 
            // button2
            // 
            button2.Location = new Point(124, 95);
            button2.Name = "button2";
            button2.Size = new Size(122, 88);
            button2.TabIndex = 2;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button_Click;
            // 
            // button3
            // 
            button3.Location = new Point(244, 95);
            button3.Name = "button3";
            button3.Size = new Size(122, 88);
            button3.TabIndex = 3;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button_Click;
            // 
            // button4
            // 
            button4.Location = new Point(5, 180);
            button4.Name = "button4";
            button4.Size = new Size(122, 88);
            button4.TabIndex = 5;
            button4.Text = "4";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button_Click;
            // 
            // button5
            // 
            button5.Location = new Point(124, 180);
            button5.Name = "button5";
            button5.Size = new Size(122, 88);
            button5.TabIndex = 6;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button_Click;
            // 
            // button6
            // 
            button6.Location = new Point(244, 180);
            button6.Name = "button6";
            button6.Size = new Size(122, 88);
            button6.TabIndex = 7;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button_Click;
            // 
            // button7
            // 
            button7.Location = new Point(5, 266);
            button7.Name = "button7";
            button7.Size = new Size(122, 88);
            button7.TabIndex = 9;
            button7.Text = "7";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button_Click;
            // 
            // button8
            // 
            button8.Location = new Point(124, 266);
            button8.Name = "button8";
            button8.Size = new Size(122, 88);
            button8.TabIndex = 10;
            button8.Text = "8";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button_Click;
            // 
            // button9
            // 
            button9.Location = new Point(244, 266);
            button9.Name = "button9";
            button9.Size = new Size(122, 88);
            button9.TabIndex = 11;
            button9.Text = "9";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button_Click;
            // 
            // buttonPlus
            // 
            buttonPlus.Location = new Point(364, 95);
            buttonPlus.Name = "buttonPlus";
            buttonPlus.Size = new Size(122, 88);
            buttonPlus.TabIndex = 13;
            buttonPlus.Text = "+";
            buttonPlus.UseVisualStyleBackColor = true;
            buttonPlus.Click += button_Click;
            // 
            // buttonLess
            // 
            buttonLess.Location = new Point(364, 180);
            buttonLess.Name = "buttonLess";
            buttonLess.Size = new Size(122, 88);
            buttonLess.TabIndex = 14;
            buttonLess.Text = "-";
            buttonLess.UseVisualStyleBackColor = true;
            buttonLess.Click += button_Click;
            // 
            // buttonMultiply
            // 
            buttonMultiply.Location = new Point(364, 266);
            buttonMultiply.Name = "buttonMultiply";
            buttonMultiply.Size = new Size(122, 88);
            buttonMultiply.TabIndex = 15;
            buttonMultiply.Text = "*";
            buttonMultiply.UseVisualStyleBackColor = true;
            buttonMultiply.Click += button_Click;
            // 
            // button0
            // 
            button0.Location = new Point(5, 350);
            button0.Name = "button0";
            button0.Size = new Size(122, 88);
            button0.TabIndex = 16;
            button0.Text = "0";
            button0.UseVisualStyleBackColor = true;
            button0.Click += button_Click;
            // 
            // buttonLimpiar
            // 
            buttonLimpiar.Location = new Point(244, 350);
            buttonLimpiar.Name = "buttonLimpiar";
            buttonLimpiar.Size = new Size(122, 88);
            buttonLimpiar.TabIndex = 18;
            buttonLimpiar.Text = "Limpiar";
            buttonLimpiar.UseVisualStyleBackColor = true;
            buttonLimpiar.Click += buttonClean_Click;
            // 
            // buttonDivide
            // 
            buttonDivide.Location = new Point(364, 350);
            buttonDivide.Name = "buttonDivide";
            buttonDivide.Size = new Size(122, 88);
            buttonDivide.TabIndex = 24;
            buttonDivide.Text = "/";
            buttonDivide.UseVisualStyleBackColor = true;
            buttonDivide.Click += button_Click;
            // 
            // buttonCalcular
            // 
            buttonCalcular.Location = new Point(5, 436);
            buttonCalcular.Name = "buttonCalcular";
            buttonCalcular.Size = new Size(481, 88);
            buttonCalcular.TabIndex = 25;
            buttonCalcular.Text = "Calcular";
            buttonCalcular.UseVisualStyleBackColor = true;
            buttonCalcular.Click += buttonEqual_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(5, 62);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(481, 27);
            textBox1.TabIndex = 26;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(5, 9);
            label1.Name = "label1";
            label1.Size = new Size(183, 28);
            label1.TabIndex = 27;
            label1.Text = "Super Calculadora";
            label1.Click += label1_Click;
            // 
            // buttonEliminar
            // 
            buttonEliminar.Location = new Point(124, 350);
            buttonEliminar.Name = "buttonEliminar";
            buttonEliminar.Size = new Size(122, 88);
            buttonEliminar.TabIndex = 28;
            buttonEliminar.Text = "Eliminar";
            buttonEliminar.UseVisualStyleBackColor = true;
            buttonEliminar.Click += button10_Click;
            // 
            // Calculadora
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(723, 536);
            Controls.Add(buttonEliminar);
            Controls.Add(label1);
            Controls.Add(textBox1);
            Controls.Add(buttonCalcular);
            Controls.Add(buttonDivide);
            Controls.Add(buttonLimpiar);
            Controls.Add(button0);
            Controls.Add(buttonMultiply);
            Controls.Add(buttonLess);
            Controls.Add(buttonPlus);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(listBox1);
            Name = "Calculadora";
            Text = "Calculadora";
            Load += Calculadora_Load;
            Click += button_Click;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox listBox1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button buttonPlus;
        private Button buttonLess;
        private Button buttonMultiply;
        private Button button0;
        private Button buttonDelete;
        private Button buttonLimpiar;
        private Button buttonDivide;
        private Button buttonCalcular;
        private TextBox textBox1;
        private Label label1;
        private Button buttonEliminar;
    }
}
