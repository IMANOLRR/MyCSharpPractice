namespace WinformCalculadora
{
    public partial class Calculadora : Form
    {
        public Calculadora()
        {
            InitializeComponent();
        }

        private double EvaluarExpresion(string expresion)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            return Convert.ToDouble(dt.Compute(expresion, ""));
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            textBox1.Text += btn.Text;
        }

        private void buttonEqual_Click(object sender, EventArgs e)
        {
            try
            {
                string expresion = textBox1.Text;
                double resultado = EvaluarExpresion(expresion);
                listBox1.Items.Add(expresion + " = " + resultado.ToString());
                textBox1.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        int num1, num2;
        string operacion;
        private void buttonPlus_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            num1 = Convert.ToInt32(textBox1.Text);
            operacion = btn.Text;
        }

        private void buttonClean_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            listBox1.Items.Clear();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0)
                textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length - 1);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string expresion = textBox1.Text;
                double resultado = EvaluarExpresion(expresion);
                listBox1.Items.Add(expresion + " = " + resultado.ToString());
                textBox1.Text = resultado.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Calculadora_Load(object sender, EventArgs e)
        {

        }


        private void label1_Click(object sender, EventArgs e)
        {

        }
    }

}
